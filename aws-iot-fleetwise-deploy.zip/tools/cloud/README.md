# AWS IoT FleetWise Cloud Demo Script

## Prerequisites
Install the dependencies:

    sudo ./install-deps.sh

## Running the Demo
Run the demo:

    ./demo.sh

